import {Component, OnInit, ViewChild} from "@angular/core";
import {LoadingController, NavController, NavParams, IonicPage, Slides, Platform, ToastController} from "ionic-angular";

import {AudioService} from "../../services/audio";
import {CheckoutPage} from "../checkout/checkout";
import {ProfilePage} from "../profile/profile";
import {Storage} from "@ionic/storage";

import { FullPackage, Packages, Audio } from "../../models/audio";
import {ConfigService} from "../../services/config";
import {UserService} from "../../services/users";

@IonicPage()
@Component({
  selector: 'page-package',
  templateUrl: 'package.html'
})
export class PackagePage implements OnInit{

  packag: Packages;
  audio: Audio;
  fullPackage = FullPackage;
  isLoggedIn:false;
  message:string;
  audiotabs: string[]=[];

  @ViewChild('PackageTabs') packageTabs: Slides;
  @ViewChild('PackageSlides') packageSlides: Slides;

  constructor(public navCtrl: NavController,
              public navParams: NavParams,
              private loadingCtrl:LoadingController,
              private audioService: AudioService,
              private toastCtrl:ToastController,
              private storage:Storage,
              private config:ConfigService,
              public userService:UserService,
  ){}


  ngOnInit() {

    this.packag = this.navParams.data.pckg;

    if('message' in this.navParams.data){
      this.message = this.navParams.get('message');
    }

    let loading = this.loadingCtrl.create({
      content: '<img src="assets/imgs/bubbles.svg">',
      duration: 15000,//this.config.get_translation('loadingresults'),
      spinner:'hide',
      showBackdrop:true,

    });


    loading.present();

    this.audioService.getFullPackage(this.packag).subscribe(res=>{
      this.fullPackage = res;
      loading.dismiss();
      for(var k in this.fullPackage){
        if(k != 'package' && k != 'purchase_link' && k != 'reviews' && k != 'instructors'){this.audiotabs.push(k);}
      }
    });
  }

  selectedTab(index){
    this.packageSlides.slideTo(index, 500);
  }

  onSlideChanged() {
    let index = this.packageSlides.getActiveIndex();
    this.packageTabs.slideTo(index,500);
  }

  purchasePackage() {
    console.log('Clocked');

    if(this.config.isLoggedIn){

      console.log('YAY ! ='+this.packag.price);
      if(this.packag.price == 0){
        console.log('YAY !')
        this.storage.remove('audios_'+this.config.user.id);
        // Or to get a key/value pair
        this.storage.remove('audios_'+this.config.user.id).then((val) => {
          console.log('Your age is', val);
        });

        this.config.removeFromTracker('profiletabs','audios');


        this.userService.addAudio(this.packag).subscribe(res=>{
          let toast = this.toastCtrl.create({
            message: res.message,
            duration: 1000,
            position: 'bottom'
          });

          if(res.status){
            toast.onDidDismiss(() => {
              this.navCtrl.setRoot(ProfilePage);
            });
          }

          toast.present();
        });
      } else {
        console.log('go for checkout');
        this.storage.remove('audios_'+this.config.user.id);
        // Or to get a key/value pair
        this.storage.remove('audios_'+this.config.user.id).then((val) => {
          console.log('Your age is', val);
        });

        this.config.removeFromTracker('profiletabs','audios');
        this.navCtrl.push(CheckoutPage,{'packages':this.packag})
      }

    }

    if(!this.config.isLoggedIn){
      //Add Checkout function
      //this.cartService.post(this.course);
      //console.log(this.course);
      //this.navCtrl.setRoot(CheckoutPage);
      let toast = this.toastCtrl.create({
        message: this.config.get_translation('register_account'),
        duration: 1000,
        position: 'bottom'
      });
      toast.present();

    }


  }

}
