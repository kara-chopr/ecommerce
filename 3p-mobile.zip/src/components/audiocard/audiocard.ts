import { Component, Input, OnInit } from '@angular/core';

import { AudioPage } from '../../pages/audio/audio';


@Component({
  selector: 'audiocard',
  templateUrl: 'audiocard.html'
})
export class Audiocard implements OnInit{

  coursePage= AudioPage;
  active:string='';
  @Input('audio') audio;

  constructor(
    ) {
  }

  ngOnInit(){

    this.audio.price = this.audio.price;
  }




}
