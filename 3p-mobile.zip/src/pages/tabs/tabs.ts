import { Component, ViewChild } from '@angular/core';
import { App, NavController, NavParams } from 'ionic-angular';

import { HomePage } from '../home/home';
import { ProfilePage } from "../profile/profile";

import { ConfigService } from '../../services/config';


@Component({
  templateUrl: 'tabs.html'
})
export class TabsPage {

  // this tells the tabs component which Pages
  // should be each tab's root Page
  myIndex:number;
  home: any = HomePage;
  profileTab: any = ProfilePage;

  page:any;
  user: any;
  userdata: any;
  coursetatusdata: any;

  constructor(
    private nav: NavController,
    private navParams: NavParams,
    private config:ConfigService
  ) {

    this.myIndex = 0;
    if (navParams.data.index){
      this.myIndex = navParams.data.index;
    }
  }

  ionViewDidEnter(){
    this.config.updateUser();
    console.log('User loggedIn', this.config.isLoggedIn);


    //console.log(this.updatesService.updates.length+'<-Unread read ->'+this.updatesService.readupdates.length)
    //this.unread_count = this.updatesService.updates.length - this.updatesService.readupdates.length;
    //console.log(this.unread_count+'<---');
  }
}
