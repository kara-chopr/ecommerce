import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PackagePage } from './package';
//import { TranslateModule } from '@ngx-translate/core';

@NgModule({
  declarations: [
    PackagePage,
  ],
  imports: [
    IonicPageModule.forChild(PackagePage),
    //TranslateModule.forChild()
  ],
  exports: [
    PackagePage
  ]
})
export class PackagePageModule { }
