import { Component } from '@angular/core';
import { NavController, NavParams, ModalController, LoadingController } from 'ionic-angular';

import {Audio, Packages} from '../../models/audio';

import { ConfigService } from '../../services/config';
import { AudioService } from '../../services/audio';

import { FixedScrollHeader } from '../../components/fixed-scroll-header/fixed-scroll-header';
import { Audiocard } from '../../components/audiocard/audiocard';

import {PackagePage} from "../package/package";
import {PlanPage} from "../plan/plan";
import { ProfilePage } from "../profile/profile";


@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {

  isLoggedIn: boolean = false;
  allAudio: Audio[] = [];
  featured: Audio[] = [];
  packages: Packages[]= [];
  profilePage=ProfilePage;


  constructor(public navCtrl: NavController,
              private modalCtrl: ModalController,
              public loadingController: LoadingController,
              private config:ConfigService,
              private audioService: AudioService,) {

  }

  ngOnInit() {
    console.log('waiting to be loaded');

    let loading = this.loadingController.create({
      content: '<img src="assets/imgs/bubbles.svg">',
      duration: 15000,//this.config.get_translation('loadingresults'),
      spinner:'hide',
      showBackdrop:true,

    });

    loading.present();

    this.config.isLoading().then(res=>{
      if(res){
        this.config.track = res;
      }

      this.audioService.getAllAudios().subscribe(allAudio =>{
        this.allAudio = allAudio;

      });

      this.audioService.getFeaturedAudios().subscribe(featured =>{
        this.featured = featured;
      });

      this.audioService.getPackeges().subscribe(popular =>{
        this.packages = popular;
        loading.dismiss();
      });
      /*

      this.courseService.getAllCourseCategory().subscribe(cats =>{
        this.categories = cats;
      });*/
    });


  }

  openPage(pckg) {
    console.log(pckg);
    this.navCtrl.push(PackagePage,{pckg});
  }

}
