import { Injectable } from "@angular/core";

import { Observable } from 'rxjs/Observable';

import { Profile, User } from "../models/user";
import { CacheService } from "ionic-cache";
import { ConfigService } from "./config";
import { Storage } from "@ionic/storage";
import { Http } from "@angular/http";

@Injectable()
export class OrderService{

  profile: Profile;

  private baseUrl:string;

  constructor(private http:Http,
              private storage: Storage,
              private cache:CacheService,
              private config:ConfigService) {

    this.baseUrl = this.config.baseUrl;

  }

  createOrder(type,user,audio,payment_id) {
    let opt = '';

    console.log('run promis');

    return this.http.post(`${this.baseUrl}createorder`,{
      'item_id':audio.id,
      'item_type':type,
      'user_id': user.id,
      'paid_amt': audio.price,
      'payment_id':payment_id
    },opt)
      .map(response =>{
        if(response.status == 400) {
          return {'message':this.config.get_translation('failed')};
        } else if(response.status == 200) {
          if(this.profile){
            if('data' in this.profile){
              delete this.profile.data['audios'];
            }
          }

          let body = response.json();
          return body;

        }
      });
  }
}
