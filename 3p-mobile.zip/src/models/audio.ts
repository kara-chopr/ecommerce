export class Audio{
  constructor(
    public id: number,
    public name: string,
    public date_created: number,
    public status: string,
    public price: any,
    public featured_img: string,
    public speed: number,
    public count: number,
    public language: any,
    public meta: any
  ){}
}

export class FullAudio{
  constructor(
    public audio: Audio,
    public purchase_link: string,
    public description: string,
  ){}
}
export class Packages {
  constructor(
    public id: number,
    public name: string,
    public featured_img: string,
    public price: any,
    public validity: number,
    public type: string
  ){}
}
export class FullPackage {
  constructor(
    public packages: Packages,
    public audio: Audio
  ){}
}
