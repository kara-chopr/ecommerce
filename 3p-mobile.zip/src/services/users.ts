import { Injectable} from '@angular/core';
import { Http, Headers, Response, RequestOptions, URLSearchParams } from '@angular/http';
import 'rxjs/add/operator/map';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import { ToastController} from 'ionic-angular';

import { User } from "../models/user";
import { Profile } from "../models/user";

import { Storage } from '@ionic/storage';
import { FileTransfer, FileTransferObject, FileUploadResult } from '@ionic-native/file-transfer';

import { ConfigService } from "./config";
import { AuthenticationService } from "./authentication";

@Injectable()
export class UserService{

  token:string;
  user: User;
  profile: Profile;
  isloggedin: boolean=false;
  profileTabPaged:number[]=[];

  saved_results:any[]=[];

  private baseUrl:string;


  private observable: Observable<any>;
  private tabobservable: Observable<any>[]=[]; //Tracks request in progress

  constructor(private http:Http,
              private auth: AuthenticationService,
              private storage: Storage,
              private config:ConfigService,
              private toastCtrl:ToastController,

              private transfer: FileTransfer) {

    this.baseUrl = this.config.baseUrl;

    this.token = this.auth.getAccessToken();
    if(this.token){
      this.isloggedin = true;
      this.auth.getUser().subscribe(res=>{
        this.user = res;
      });
    }
  }

  addAudio(course:any){
    let opt = '';

    return this.http.post(`${this.baseUrl}user/subscribe`,{
      'course_id':course.id,
    },opt)
      .map(response =>{
        if(response.status == 400) {
          return {'message':this.config.get_translation('failed')};
        } else if(response.status == 200) {
          if(this.profile){
            if('data' in this.profile){
              delete this.profile.data['audios'];
            }
          }

          let body = response.json();
          return body;

        }
      });
  }

  public getProfile(user){

    let loadedprofile = this.config.trackComponents('profile');

    if(loadedprofile){
      if(this.profile){
        return Observable.of(this.profile);
      }else{
        return Observable.fromPromise(this.storage.get('profile').then((profile) => {

          this.profile=profile;
          return this.profile;
        }));
      }
    }else{
      if(this.observable) {
        return this.observable;
      }else{

        let opt = '';

        console.log('userId for profile:-',user)

        this.observable =  this.http.get(`${this.baseUrl}user/profile/`+user.id,opt)
          .map(response =>{
            this.observable = null;
            if(response.status == 400) {
              return "FAILURE";
            } else if(response.status == 200) {

              let body = response.json();
              if(body){
                this.profile = body;
                this.storage.set('profile',this.profile	);
                this.config.updateComponents('profile',1);
                return body;
              }
            }
          });

        return this.observable;
      }
    }
  }

  public getProfileTab(user_id:any,key:string,force:boolean=false){

    let loadedtabs = this.config.trackComponents('profiletabs');

    if(loadedtabs.indexOf(key) == -1 || force){

      if(this.tabobservable[key]) {
        return this.tabobservable[key];
      }else{

        this.profileTabPaged[key]=1;
        let opt = '';
        let url = `${this.baseUrl}user/profile?tab=`+key+`&user=`+user_id;



        this.tabobservable[key] =  this.http.get(url,opt)
          .map(response =>{
            this.tabobservable[key] = null;
            if(response.status == 400) {
              return "FAILURE";
            } else if(response.status == 200) {
              let body = response.json();

              if(body){
                this.storage.set(key+'_'+user_id,body);


                this.profile.data[key] = body;

                this.config.addToTracker('profiletabs',key);
                return body;
              }
            }
          });
        return this.tabobservable[key];
      }
    }else{

      if(this.profile && this.profile.data[key]){

        return Observable.of(this.profile.data[key]);
      }else{
        if(!this.user){
          this.user = this.config.track.user;
        }
        return Observable.fromPromise(this.storage.get(key+'_'+this.user.id).then((profiletab) => {
          //console.log('fetching '+key+' from local');
          this.profile.data[key] = profiletab;
          return profiletab;
        }));
      }
    }


  }

  getUser(){
    return this.auth.getUser();
  }

  public getResults(){
    this.storage.get('saved_results_'+this.config.user.id).then(res=>{
      if(res){
        this.saved_results = res;
      }
    });
  }
}
