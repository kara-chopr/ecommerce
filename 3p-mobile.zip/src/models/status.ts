import { Audio } from './audio';
import { User } from './user';

export class AudioStatus{
  constructor(
    public user_id: number,
    public audio_id: number,
    public progress: number,
    public audio_file: string,
    public pdf_file : string,
    public image: string,
    public description: any,
    public wpm: number,
    public word_count: number,
    public language: string,
    public magazine: string,
    public status:number,
    public courseitems: CourseItem[],
  ){}
}

export class CourseItem{
  constructor(
    public id: number,
    public key: number,
    public type: string,
    public title: string,
    public duration: number,
    public status: number,
    public content: string,
    public meta: any,
  ){}
}
