import { Component, OnInit, ViewChild } from '@angular/core';
import { NavController, NavParams, ModalController,ToastController,LoadingController, Platform, Slides } from 'ionic-angular';

import {Audio, FullAudio, Packages} from "../../models/audio";
import { ConfigService } from "../../services/config";
import { User } from "../../models/user";
import { RozarpayService } from "../../services/rozarpay";



@Component({
  selector: 'page-checkout',
  templateUrl: 'checkout.html'
})
export class CheckoutPage implements OnInit{

  audio:Audio;
  pckg:Packages;
  fullAudio: FullAudio;
  user: User;

  constructor(public navCtrl: NavController,
              public navParams: NavParams,
              private config:ConfigService,
              private rozarpay:RozarpayService) {

  }

  ngOnInit() {
    this.audio = this.navParams.data.audio;
    this.pckg = this.navParams.data.packages;
    this.user = this.config.user;


  }

  payAudio(){

    this.rozarpay.init(this.audio,this.user);
  }

  payPackage() {
    this.rozarpay.pay(this.pckg,this.user);
  }
}
