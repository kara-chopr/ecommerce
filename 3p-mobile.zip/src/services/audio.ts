import { Injectable, OnInit } from '@angular/core';
import { Http, Headers, Response, RequestOptions, URLSearchParams } from '@angular/http';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/fromPromise';
import 'rxjs/add/operator/map';
import 'rxjs/add/observable/of';

import { CacheService } from "ionic-cache";

import { Storage } from '@ionic/storage';

import {Audio, FullPackage, Packages} from '../models/audio';
import { FullAudio } from '../models/audio';

import { ConfigService } from "./config";


@Injectable()
export class AudioService implements OnInit{

  audios: Audio[] =[];
  featured: Audio[] =[];
  fullAudio: FullAudio[] =[];
  packages: Packages[] = [];
  fullPackage: FullPackage[] = [];
  lastAudio:any;

  private baseUrl:string;
  private observable: Observable<any>; //Tracks request in progress
  private allaudiosobservable: Observable<any>;
  private featuredobservable:Observable<any>;
  private packageobservable:Observable<any>;
  private fullpackageobservable:Observable<any>;
  private fullaudioobservable: Observable<any>;

  constructor(private http:Http,
              private storage: Storage,
              private cache:CacheService,
              private config:ConfigService) {

    this.baseUrl = this.config.baseUrl;

  }

  ngOnInit(){
    this.cache.setDefaultTTL(this.config.environment.cacheDuration);
    this.cache.setOfflineInvalidate(false);
    if(this.config.track){
      //this.cache.clearGroup("cacheGroup");
    }

  }

  private extractData(response: Response) {
    let body = response.json();
    if(body){
      let res = [];
      for(let i=0;i<body.length;i++){
        res.push(body[i].data);
      }
      return res;
    }
    return {};
  }

  getAllAudios(paged:number = 1){


    if(this.config.trackComponents('allaudios') ){
      if(this.audios.length){
        return Observable.of(this.audios);
      }else{
        this.allaudiosobservable = Observable.fromPromise(this.storage.get('allaudios').then((audios) => {
          if(audios){
            this.audios = audios;
            return this.audios;
          }
        }));
      }

    }else{

      let count:number=0;
      count = paged*this.config.per_view - this.audios.length;

      if(this.allaudiosobservable) {
        return this.allaudiosobservable;
      }else{

        this.allaudiosobservable = this.http.get(`${this.baseUrl}all-audio`+'?per_view='+this.config.per_view)
          .map(response =>{
            let body = response.json();
            this.allaudiosobservable = null;
            if(body){
              let courses = [];
              for(let i=0;i<body.length;i++){
                courses.push(body[i].data);
              }
              this.audios = this.mergeAudios(this.audios,courses);
              //this.popular = this.mergeCourses(this.popular,courses);
              this.storage.set('allaudios',this.audios);
              this.config.updateComponents('allaudios',1);
              return this.audios;
            }
          });

       }
    }

    return this.allaudiosobservable;
  }

  /*
    FEATURED COURSES
    */

  getFeaturedAudios(){

    console.log('Shall track featured = '+this.config.trackComponents('featured'));
    if(this.config.trackComponents('featured')){

      if(this.featured.length){
        console.log('getting');
        return Observable.of(this.featured);
      }else{
        this.featuredobservable = Observable.fromPromise(
          this.storage.get('featured').then((featured) => {
            if(featured){
              this.featured = featured;
              return this.featured;
            }
          }));
      }
    }else{
      this.featuredobservable = this.http.get(`${this.baseUrl}featured-audio?per_view=`+this.config.per_view)
        .map(response =>{
          let body = response.json();
          if(body){
            let courses = [];
            for(let i=0;i<body.length;i++){
              courses.push(body[i].data);
            }
            console.log('#7');
            this.audios = this.mergeAudios(this.audios,courses);
            this.featured = this.mergeAudios(this.featured,courses);
            this.storage.set('featured',this.featured);
            this.config.updateComponents('featured',1);
            return this.featured;
          }
        });
    }
    return this.featuredobservable;

  }

  getPackeges() {
    console.log('Shall track package = '+this.config.trackComponents('package'));
    if(this.config.trackComponents('package')){

      if(this.packages.length){
        return Observable.of(this.packages);
      }else{
        this.packageobservable = Observable.fromPromise(
          this.storage.get('package').then((packages) => {
            if(packages){
              this.packages = packages;
              return this.packages;
            }
          }));
      }
    }else{
      this.packageobservable = this.http.get(`${this.baseUrl}packages?per_view=`+this.config.per_view)
        .map(response =>{
          let body = response.json();
          if(body){
            let courses = [];
            for(let i=0;i<body.length;i++){
              courses.push(body[i].data);
            }
            console.log('#7');
            this.packages = this.mergePackages(this.packages,courses);
            this.packages = this.mergePackages(this.packages,courses);
            this.storage.set('package',this.packages);
            this.config.updateComponents('package',1);
            return this.packages;
          }
        });
    }
    return this.packageobservable;
  }

  /*
    Full course call
     */


  getFullAudio(audio:any){


    let allc = this.config.trackComponents('audios');
    if(Array.isArray(allc) && allc.indexOf(audio.id) != -1){
      let flag =1;
      if(Array.isArray(this.fullAudio)){
        if(this.fullAudio.length){
          for(let i=0;i<this.fullAudio.length;i++){
            if(this.fullAudio[i].audio.id == audio.id){
              flag=0;
              return Observable.of(this.fullAudio[i]); //return if already cached
            }
          }
        }
      }

      if(flag){
        console.log('Storage Full course');
        this.fullaudioobservable = Observable.fromPromise(this.storage.get('fullaudio_'+audio.id).then((fullaudio) => {

          if(fullaudio){

            this.fullAudio.push(fullaudio);
            return fullaudio;
          }

        }));
      }

    }else{

      if(this.fullaudioobservable) {
        return this.fullaudioobservable;
      }else{
        let k = 0;
        if(this.fullAudio){
          let k = this.fullAudio.length;
        }
        let fullAudio = <FullAudio>{};
        this.fullaudioobservable =  this.http.get(`${this.baseUrl}full-audio/`+audio.id)
          .map(response =>{

            this.fullaudioobservable = null;

            if(response.status == 400) {
              return "FAILURE";
            } else if(response.status == 200) {

              let body = response.json();
              if(body){
                let res = [];
                for(let i=0;i<body.length;i++){
                  res.push(body[i].data);
                }
                if(res){

                  fullAudio = res[0];
                  console.log('############');
                  /*
                  Object.keys(res[0]).forEach(function (key) {
                      if(key == 'course'){
                          fullCourse['course'] = body[key];
                      }else if(key == 'curriculum'){
                          fullCourse['curriculum']=body[key];
                      }else if(key == 'description'){
                          fullCourse['description']=body[key];
                      }else if(key == 'reviews'){
                          fullCourse['reviews']=body[key];
                      }else if(key == 'purchase_link'){
                          fullCourse['purchase_link']=body[key];
                      }else if(key == 'instructors'){
                          fullCourse['instructors']=body[key];
                      }
                  });*/
                  console.log('setting full course in storage');
                  this.storage.set('fullaudio_'+audio.id,fullAudio);
                  this.config.addToTracker('audios',audio.id);
                  this.fullAudio.push(fullAudio);
                  console.log('end storage');
                  return fullAudio;
                }
              }
            }

          });

      }
    }

    return this.fullaudioobservable;
  }

  /*
    Full course call
     */


  getFullPackage(packag:any){


    let allc = this.config.trackComponents('package');
    if(Array.isArray(allc) && allc.indexOf(packag.id) != -1){
      let flag =1;
      if(Array.isArray(this.fullPackage)){
        if(this.fullPackage.length){
          for(let i=0;i<this.fullPackage.length;i++){
            if(this.fullPackage[i].packages.id == packag.id){
              flag=0;
              return Observable.of(this.fullPackage[i]); //return if already cached
            }
          }
        }
      }

      if(flag){
        console.log('Storage Full package', packag);
        this.fullpackageobservable = Observable.fromPromise(this.storage.get('fullpackage_'+packag.id).then((fullpackage) => {

          if(fullpackage){

            this.fullPackage.push(fullpackage);
            return fullpackage;
          }

        }));
      }

    }else{

      if(this.fullpackageobservable) {
        return this.fullpackageobservable;
      }else{
        let k = 0;
        if(this.fullPackage){
          let k = this.fullPackage.length;
        }
        let fullPackage = <FullPackage>{};
        this.fullpackageobservable =  this.http.get(`${this.baseUrl}package-detail/`+packag.id)
          .map(response =>{

            this.fullpackageobservable = null;

            if(response.status == 400) {
              return "FAILURE";
            } else if(response.status == 200) {

              let body = response.json();
              if(body){
                let res = [];
                for(let i=0;i<body.length;i++){
                  res.push(body[i].data);
                }
                if(res){

                  fullPackage = res[0];
                  console.log('############');

                  console.log('respon', res[0]);
                  /*
                  Object.keys(res[0]).forEach(function (key) {
                      if(key == 'course'){
                          fullCourse['course'] = body[key];
                      }else if(key == 'curriculum'){
                          fullCourse['curriculum']=body[key];
                      }else if(key == 'description'){
                          fullCourse['description']=body[key];
                      }else if(key == 'reviews'){
                          fullCourse['reviews']=body[key];
                      }else if(key == 'purchase_link'){
                          fullCourse['purchase_link']=body[key];
                      }else if(key == 'instructors'){
                          fullCourse['instructors']=body[key];
                      }
                  });*/
                  console.log('setting full package in storage');
                  this.storage.set('fullpackage_'+packag.id,fullPackage);
                  this.config.addToTracker('package',packag.id);
                  this.fullPackage.push(fullPackage);
                  console.log('end storage');
                  return fullPackage;
                }
              }
            }

          });

      }
    }

    return this.fullpackageobservable;
  }

  public mergeAudios(coursesA: Audio[],coursesB: any){

    for(let i=0;i<coursesB.length;i++){
      var flag = 1;
      for(let j=0;j<coursesA.length;j++){
        if(coursesB[i].id == coursesA[j].id){
          flag= 0;
        }
      }
      if(flag){
        coursesA.push(coursesB[i]);
      }
    }
    return coursesA;
  }

  public mergePackages(packageA: Packages[],packageB: any){

    for(let i=0;i<packageB.length;i++){
      var flag = 1;
      for(let j=0;j<packageA.length;j++){
        if(packageB[i].id == packageA[j].id){
          flag= 0;
        }
      }
      if(flag){
        packageA.push(packageB[i]);
      }
    }
    return packageA;
  }

  getLastAudio(){
    console.log("GET");
    return this.lastAudio;
  }

}
