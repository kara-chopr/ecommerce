import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';
import { SplashScreen } from '@ionic-native/splash-screen';
import { StatusBar } from '@ionic-native/status-bar';
import { Storage, IonicStorageModule } from '@ionic/storage';
import { FileTransfer } from '@ionic-native/file-transfer';
import {DocumentViewer, DocumentViewerOptions} from '@ionic-native/document-viewer';
import { File } from '@ionic-native/file';

import { LazyImgComponent }   from '../components/lazy-img/lazy-img';
import { LazyLoadDirective }   from '../directives/lazy-load.directive';
import { PressDirective }   from '../directives/longPress.directive';

import { ImgcacheService } from "../services/imageCache";

import { CacheModule } from "ionic-cache";

import {HttpModule} from '@angular/http';

import { Audiocard } from '../components/audiocard/audiocard';
import { FixedScrollHeader } from '../components/fixed-scroll-header/fixed-scroll-header';
import { ElasticHeader } from '../components/elastic-header/elastic-header';
import { CallbackPipe } from '../components/pipefilters';

import { MyApp } from './app.component';
import { HomePage } from '../pages/home/home';
import { Settings } from '../providers/providers';
import { TutorialPage } from "../pages/tutorial/tutorial";
import { TabsPage } from "../pages/tabs/tabs";
import { AudioPage } from '../pages/audio/audio';
import { ProfilePage } from '../pages/profile/profile';
import { CheckoutPage } from "../pages/checkout/checkout";
import { AudioStatusPage } from "../pages/audio-status/audio-status";
import { PackagePage } from "../pages/package/package";


import { ConfigService } from "../services/config";
import { AudioService } from "../services/audio";
import { RozarpayService } from "../services/rozarpay";
import { OrderService } from "../services/order";
import { AuthenticationService } from '../services/authentication';
import { UserService } from '../services/users';

import { VgCoreModule } from 'videogular2/core';
import { VgControlsModule } from 'videogular2/controls';
import { VgOverlayPlayModule } from 'videogular2/overlay-play';

import { PdfViewerModule } from 'ng2-pdf-viewer';



export function provideSettings(storage: Storage) {
  /**
   * The Settings provider takes a set of default settings for your app.
   *
   * You can add new settings options at any time. Once the settings are saved,
   * these values will not overwrite the saved values (this can be done manually if desired).
   */
  return new Settings(storage, {
    option1: true,
    option2: 'Ionitron J. Framework',
    option3: '3',
    option4: 'Hello'
  });
}

@NgModule({
  declarations: [
    MyApp,
    HomePage,
    TabsPage,
    ProfilePage,
    CheckoutPage,
    AudioStatusPage,
    Audiocard,
    TutorialPage,
    PackagePage,
    AudioPage,
    ElasticHeader,
    CallbackPipe,
    FixedScrollHeader,
    LazyImgComponent,
    LazyLoadDirective,
    PressDirective,
  ],
  imports: [
    BrowserModule,
    PdfViewerModule,
    HttpModule,
    CacheModule.forRoot(),
    IonicModule.forRoot(MyApp),
    IonicStorageModule.forRoot(),
    VgCoreModule,
    VgControlsModule,
    VgOverlayPlayModule
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    HomePage,
    TutorialPage,
    TabsPage,
    CheckoutPage,
    AudioStatusPage,
    PackagePage,
    AudioPage,
    ProfilePage,
    LazyImgComponent
  ],
  providers: [
    StatusBar,
    File,
    SplashScreen,
    FileTransfer,
    DocumentViewer,
    ConfigService,
    AuthenticationService,
    UserService,
    OrderService,
    RozarpayService,
    AudioService,
    ImgcacheService,
    { provide: Settings, useFactory: provideSettings, deps: [Storage] },
    {provide: ErrorHandler, useClass: IonicErrorHandler}
  ]
})
export class AppModule {}
