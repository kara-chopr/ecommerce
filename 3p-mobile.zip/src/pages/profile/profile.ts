import { Component, OnInit, ViewChild } from '@angular/core';
import { NavController,ViewController,LoadingController, ToastController,ActionSheetController,AlertController, NavParams, Slides,Platform } from 'ionic-angular';
import { FormBuilder, FormGroup,FormControl, Validators, } from '@angular/forms';
import { Storage } from '@ionic/storage';

import { AuthenticationService } from '../../services/authentication';
import { UserService } from '../../services/users';
import { ConfigService } from '../../services/config';

import { User } from '../../models/user';
import { Profile } from '../../models/user';

import { TabsPage } from "../tabs/tabs";
import { AudioStatusPage } from '../audio-status/audio-status';


@Component({
  selector: 'page-profile',
  templateUrl: 'profile.html'
})
export class ProfilePage implements OnInit {

  isLoggedIn: boolean = false;
  register: boolean = false;
  signin: boolean = false;
  user: User;
  profile: Profile;
  filterargs:any;
  signupForm: FormGroup;
  signinForm: FormGroup;
  profileTab:any;
  imageSrc: string;
  audioStatusPage = AudioStatusPage;

  signupFields:{
    'phone':null,
    'email':null,
    'password':null,
  };

  signinFields:{
    'email':null,
    'password':null,
  };

  more:any={
    'audios':1,

  };

  @ViewChild('ProfileTabs') profileTabs: Slides;
  @ViewChild('ProfileSlides') profileSlides: Slides;

  constructor(private navCtrl: NavController,
              private viewCtrl: ViewController,
              private toastCtrl: ToastController,
              private navParams : NavParams,
              private auth: AuthenticationService,
              private userService:UserService,
              private platform:Platform,
              private config:ConfigService,
              private storage:Storage,
              private formBuilder:FormBuilder,
              private loadingCtrl:LoadingController,
              private action:ActionSheetController,
              private alertCtrl:AlertController,

  ) {

    this.register = false;
    this.signin = false;
    this.signupForm = formBuilder.group({
      phone: ['',Validators.compose([Validators.required,Validators.maxLength(10),
        Validators.pattern(/[a-zA-Z0-9_]+/)]),
      ],
      email: ['', Validators.compose(
        [Validators.required,Validators.maxLength(40),
          Validators.pattern(/[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/) ])],
      password: ['', Validators.required],
    });

    this.signinForm = formBuilder.group({
      email: ['',Validators.required],
      password: ['', Validators.required],
    });
  }

  ngOnInit(){
    this.filterargs = {type:'number'};

    this.isLoggedIn = this.config.isLoggedIn;
    this.user = this.config.user;

    if(!this.config.isLoggedIn){
      this.isLoggedIn = false;
    }

    if(this.isLoggedIn){


      //this.profileTab = this.navParams.data.index;
      this.userService.getProfile(this.user).subscribe(res=>{
        if(res){
          this.profile = res;
          //this.profileSlides.slideTo(this.profileTab, 0);

          console.log('Tabs', this.profile.tabs)
        }
      });
    }
  }

  ionViewDidLoad(){


    if(this.config.isLoggedIn){



      this.userService.getResults();


    }
  }

  filterDashData(d:any){
    return d.type == 'number';
  }

  filterObjectData(d:any){
    return d.type == 'objects';
  }

  showSignIn(){
    this.signin = true;
  }

  onSignIn(){
    if(this.signinForm.valid){

      let loading = this.loadingCtrl.create({
        content: '<img src="assets/imgs/bubbles.svg">',
        duration: 15000,//this.config.get_translation('loadingresults'),
        spinner:'hide',
        showBackdrop:true,

      });

      loading.present();
      this.auth.signinUser(this.signinForm.value).subscribe(res=>{
        if(res){

          let toast = this.toastCtrl.create({
            message: res.message,
            duration: 1000,
            position: 'bottom'
          });

          if(res.status){
            this.userService.getUser();
            toast.onDidDismiss(() => {
              this.navCtrl.setRoot(TabsPage);
            });
          }

          toast.present();
          loading.dismiss();

        }
      },
        error => {
          let toast = this.toastCtrl.create({
            message: error._body,
            duration: 1000,
            position: 'bottom'
          });

          toast.present();
          loading.dismiss();
        });

    }
  }

  onSignUp(){
    console.log(this.signupForm);

    let loading = this.loadingCtrl.create({
      content: '<img src="assets/imgs/bubbles.svg">',duration: 15000,//this.config.get_translation('loadingresults'),
      spinner:'hide',
      showBackdrop:true,

    });

    loading.present();

    if(this.signupForm.valid){

      this.auth.registerUser(this.signupForm.value).subscribe(res=>{
        if(res){
          loading.dismiss();

          let toast = this.toastCtrl.create({
            message: res.message,
            duration: 2000,
            position: 'bottom'
          });

          if(res.status){
            this.userService.getUser();
            toast.onDidDismiss(() => {
              this.navCtrl.setRoot(TabsPage);
            });
          }

          toast.present();
        }
      });
    }
  }

  doRefresh(refresher){
    let index = this.profileSlides.getActiveIndex();
    let key = this.profile.tabs[index].key;
    console.log(key+'<<<<');
    this.userService.getProfileTab(this.config.user.id,key,true).subscribe(res=>{
      this.profile = this.userService.profile;
      refresher.complete();
    });
  }

  enableRegister(){
    this.register = true;
  }

  backToLogin(){
    this.register = false;
    this.signin = false;
  }

  onTabChanged(){
    let index = this.profileTabs.getActiveIndex();
    this.profileSlides.slideTo(index, 500);
  }

  selectedTab(index:number){
    this.profileSlides.slideTo(index, 500);
  }

  onSlideChanged(){
    let index = this.profileSlides.getActiveIndex();
    this.profileTabs.slideTo(index,500);

    let key = this.profile.tabs[index].key;
    if(!this.profile.data.hasOwnProperty(key)){
      let id:any;
      if('id' in this.user){
        id = this.user.id;
      }else{
        id = this.user;
      }
      let loading = this.loadingCtrl.create({
        content: '<img src="assets/imgs/bubbles.svg">',duration: 15000,//this.config.get_translation('loadingresults'),
        spinner:'hide',
        showBackdrop:true,

      });
      loading.present();

      this.userService.getProfileTab(id,key).subscribe(res=>{
        loading.dismiss();
        this.profile = this.userService.profile;
        //this.profile.data[key] = res;
      });

    }
  }

  logout(){
    this.storage.clear();
  }

  initiate_logout(){
    let alert = this.alertCtrl.create({
      title: this.config.get_translation('logout_from_device'),
      buttons: [
        {
          text: this.config.get_translation('cancel'),
          role: 'cancel',
          handler: data => {
          },
        },
        {
          text: this.config.get_translation('logout'),
          handler: data => {
            this.logout();
            this.navCtrl.setRoot(TabsPage);
          }
        }
      ]
    });

    alert.present();
  }

  changeImage(){
    return;
  }
}
