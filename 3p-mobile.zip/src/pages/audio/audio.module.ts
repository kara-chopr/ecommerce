import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AudioPage } from './audio';
//import { TranslateModule } from '@ngx-translate/core';

@NgModule({
  declarations: [
    AudioPage,
  ],
  imports: [
    IonicPageModule.forChild(AudioPage),
    //TranslateModule.forChild()
  ],
  exports: [
    AudioPage
  ]
})
export class AudioPageModule { }
