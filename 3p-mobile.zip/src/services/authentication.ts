import { Injectable,  } from '@angular/core';
import { Http, Headers, Response, RequestOptions, URLSearchParams } from '@angular/http';
import { Platform, LoadingController, ToastController } from 'ionic-angular';
import { Storage } from '@ionic/storage';

import 'rxjs/add/operator/map';

import { Observable } from 'rxjs/Observable';
import { User } from "../models/user";

import { ConfigService } from "./config";

@Injectable()
export class AuthenticationService {

  client_id: string;
  client_secret: string;
  redirect_uri: string;
  state: string;


  browser:any;

  //For Testing purpose
  headers: any;
  access_token: string;
  authCode: string;

  user:User;
  private observable: Observable<any>; //Tracks request in progress
  private baseUrl;

  constructor(
    public http:Http,
    private platform : Platform,
    private storage: Storage,
    private config:ConfigService,
    public loadingCtrl:LoadingController,
    public toastCtrl:ToastController
  ) {

    this.baseUrl = this.config.settings.oAuthUrl;
    this.client_id = this.config.settings.client_id;
    this.client_secret = this.config.settings.client_secret;
    this.redirect_uri = this.config.settings.url;
    this.state = this.config.settings.state;



    this.access_token = this.config.settings.access_token;//'mbyrxvaoicy7encgoi3t62jt1koiq6szqmystpt0';

  }

  public getAccessToken(){

    if(this.access_token)
      return this.access_token;
    else
      return this.config.settings.access_token;

  }

  public setAccessToken(token:any){

    if(token){
      this.access_token =  token;

      this.config.set_settings('access_token',token);
    }
  }

  public signinUser(form:any): Observable<any>{

    if(this.observable) {
      console.log('User signin pending');
      return this.observable;
    }else{
      //form.client_id = this.client_id;
      //form.state = this.config.settings.state;


      let options = '';

      this.observable =  this.http.post(`${this.config.baseUrl}login`,form,options)
        .map(response =>{
          this.observable = null;

          if(response.status == 400) {
            return "FAILURE";
          } else if(response.status == 200) {

            let body = response.json();
            if(body.status){
              this.setAccessToken(body.token.access_token);
              this.setUser(body.user);
              this.config.track.counter--;
              //this.config.getTracker();
            }

            return {'status':body.status,'message':body.message};
          }
        });

      return this.observable;
    }

  }

  public registerUser(form:any): Observable<any>{

    if(this.observable) {
      console.log('User registration pending');
      return this.observable;
    }else{
      form.client_id = this.client_id;
      form.state = this.config.settings.state;


      let headers = new Headers({
        'Content-Type': 'application/json'
      });
      let options = new RequestOptions({
        headers: headers
      });

      this.observable =  this.http.post(`${this.config.baseUrl}register`,form,options)
        .map(response =>{
          this.observable = null;

          if(response.status == 400) {
            return "FAILURE";
          } else if(response.status == 200) {

            let body = response.json();
            if(body.status){
              this.setAccessToken(body.token.access_token);
              this.setUser(body.user);
            }

            return {'status':body.status,'message':body.message};
          }
        });

      return this.observable;
    }

  }

  public setUser(user:any){
    this.user = user;
    this.storage.set('user',this.user);
    this.config.addToTracker('user',user);
  }

  getUser(){

    if(this.config.trackComponents('user')){
      if(this.user){
        return Observable.of(this.user);
      }else{
        this.storage.get('user').then((user) => {
          console.log('usee', user)
          this.user = user;
          return Observable.of(this.user);
        });
      }
    }else{

    }
    return this.observable;
  }
}
