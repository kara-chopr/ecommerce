import { Component, OnInit, ViewChild } from '@angular/core';
import { NavController, NavParams, ModalController,ToastController,LoadingController, Platform, Slides } from 'ionic-angular';

import { Storage } from '@ionic/storage';

import { ProfilePage } from "../profile/profile";

import { Audio, FullAudio } from '../../models/audio';

import { ConfigService } from '../../services/config';
import { UserService } from '../../services/users';

import { AudioService } from '../../services/audio';
import {CheckoutPage} from "../checkout/checkout";


@Component({
  selector: 'page-audio',
  templateUrl: 'audio.html'
})
export class AudioPage implements OnInit{

  isLoggedIn:false;
  message:string;

  myAudio:boolean=false;
  myAudiostatus:number=0;

  audio:Audio;
  fullAudio: FullAudio;
  coursetabs: string[]=[];

  @ViewChild('CourseTabs') courseTabs: Slides;
  @ViewChild('CourseSlides') courseSlides: Slides;

  constructor(public navCtrl: NavController,
              public navParams: NavParams,
              private toastCtrl:ToastController,
              public platform: Platform,
              private storage:Storage,
              private loadingCtrl:LoadingController,
              private audioService: AudioService,
              private config:ConfigService,
              public userService:UserService,) {

  }

  ngOnInit() {

    this.audio = this.navParams.data;

    if('message' in this.navParams.data){
      this.message = this.navParams.get('message');
    }

    let loading = this.loadingCtrl.create({
      content: '<img src="assets/imgs/bubbles.svg">',
      duration: 15000,//this.config.get_translation('loadingresults'),
      spinner:'hide',
      showBackdrop:true,

    });

    loading.present();

    this.audioService.getFullAudio(this.audio).subscribe(res=>{
      this.fullAudio = res;
      loading.dismiss();
      for(var k in this.fullAudio){
        if(k != 'audio' && k != 'purchase_link' && k != 'reviews' && k != 'instructors'){this.coursetabs.push(k);}
      }
    });

    if(this.config.isLoggedIn){
      this.storage.get('audios_'+this.config.user.id).then(audios=>{
        console.log(audios);
        if(audios){
          if(Array.isArray(audios)){
            for(let i=0;i<audios.length;i++){
              if(audios[i].id == this.audio.id){
                this.myAudio=true;
                this.myAudiostatus=audios[i].user_status;
              }
            }
          }
        }
      });
    }
  }

  selectedTab(index){
    this.courseSlides.slideTo(index, 500);
  }

  onTabChanged() {
    let index = this.courseTabs.getActiveIndex();
    this.courseSlides.slideTo(index, 500);
  }

  onSlideChanged() {
    let index = this.courseSlides.getActiveIndex();
    this.courseTabs.slideTo(index,500);
  }

  purchaseCourse(){

    console.log('Clocked');

    if(this.config.isLoggedIn){

      console.log('YAY ! ='+this.fullAudio.audio.price);
      if(this.fullAudio.audio.price == 0){
        console.log('YAY !')
        this.storage.remove('audios_'+this.config.user.id);
        this.storage.remove('fullaudio_'+this.audio.id);
        this.config.removeFromTracker('courses',this.audio.id);
        this.config.removeFromTracker('profiletabs','audios');


        this.userService.addAudio(this.audio).subscribe(res=>{
          let toast = this.toastCtrl.create({
            message: res.message,
            duration: 1000,
            position: 'bottom'
          });

          if(res.status){
            toast.onDidDismiss(() => {
              this.navCtrl.setRoot(ProfilePage);
            });
          }

          toast.present();
        });
      } else {
        console.log('go for checkout')
        this.navCtrl.push(CheckoutPage,{'audio':this.audio})
      }

    }

    if(!this.config.isLoggedIn){
      //Add Checkout function
      //this.cartService.post(this.course);
      //console.log(this.course);
      //this.navCtrl.setRoot(CheckoutPage);
      let toast = this.toastCtrl.create({
        message: this.config.get_translation('register_account'),
        duration: 1000,
        position: 'bottom'
      });
      toast.present();

    }

    console.log(this.fullAudio.audio['price']+' res = '+ (this.fullAudio['price'] == 0 )+' && loggedin = '+ this.config.isLoggedIn);



  }

}
