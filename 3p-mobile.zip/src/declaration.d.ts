declare module '*';
declare module 'imgcache.js';

declare var RazorpayCheckout: any;
