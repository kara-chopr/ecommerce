import {Injectable} from "@angular/core";

import { Observable } from 'rxjs/Observable';

import { User } from "../models/user";

import { OrderService } from "./order";
import {ProfilePage} from "../pages/profile/profile";
import {ToastController} from "ionic-angular";


@Injectable()
export class RozarpayService{

  constructor(private order:OrderService,
              private toastCtrl:ToastController) {

  }


  init(audio:any,user:any) {
    console.log('Checkout:-' , typeof audio.price);
    console.log('User:- ', user);


    var options = {
      description: 'Credits towards consultation',
      image: audio.featured_img,
      currency: 'INR',
      key: 'rzp_test_4e7zShrTzbKliz',
      amount: audio.price * 100,
      name: '3p Online',
      prefill: {
        email: user.email,
        contact: user.phone,
        name: user.name
      },
      theme: {
        color: '#009dd8'
      },
      modal: {
        ondismiss: function() {
          alert('dismissed')
        }
      }
    };

    var successCallback = function(payment_id) {
      //successCallback.bind(this);
      alert('payment_id: ' + payment_id);

      //this.successOrder('audio',user.id,audio.price,payment_id);
      this.order.createOrder('audio',user,audio,payment_id).subscribe(res=>{
        let toast = this.toastCtrl.create({
          message: res.message,
          duration: 1000,
          position: 'bottom'
        });

        if(res.status){
          toast.onDidDismiss(() => {
            this.navCtrl.setRoot(ProfilePage);
          });
        }

        toast.present();
      });;
    };

    var cancelCallback = function(error) {
      alert(error.description + ' (Error ' + error.code + ')');
    };



    RazorpayCheckout.open(options, successCallback.bind(this), cancelCallback);


  }

  pay(audio:any,user:any) {
    console.log('Checkout:-' , typeof audio.price);
    console.log('User:- ', user);


    var options = {
      description: 'Credits towards consultation',
      image: audio.featured_img,
      currency: 'INR',
      key: 'rzp_test_4e7zShrTzbKliz',
      amount: audio.price * 100,
      name: '3p Online',
      prefill: {
        email: user.email,
        contact: user.phone,
        name: user.name
      },
      theme: {
        color: '#009dd8'
      },
      modal: {
        ondismiss: function() {
          alert('dismissed')
        }
      }
    };

    var successCallback = function(payment_id) {
      //successCallback.bind(this);
      alert('payment_id: ' + payment_id);

      //this.successOrder('audio',user.id,audio.price,payment_id);
      this.order.createOrder('package',user,audio,payment_id).subscribe(res=>{
        let toast = this.toastCtrl.create({
          message: res.message,
          duration: 1000,
          position: 'bottom'
        });

        if(res.status){
          toast.onDidDismiss(() => {
            this.navCtrl.setRoot(ProfilePage);
          });
        }

        toast.present();
      });;
    };

    var cancelCallback = function(error) {
      alert(error.description + ' (Error ' + error.code + ')');
    };



    RazorpayCheckout.open(options, successCallback.bind(this), cancelCallback);


  }


}
