import {Component, OnInit } from '@angular/core';
import {Platform, App, LoadingController} from 'ionic-angular';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { Storage } from '@ionic/storage';
import { ImgcacheService } from '../services/imageCache';

import { HomePage } from '../pages/home/home';
import { TutorialPage } from "../pages/tutorial/tutorial";
import { TabsPage } from '../pages/tabs/tabs';
import { AudioPage } from '../pages/audio/audio';
import { PlanPage } from "../pages/plan/plan";
import { ConfigService } from '../services/config';

@Component({
  templateUrl: 'app.html'
})
export class MyApp implements OnInit{
  tabsPage = TabsPage;
  rootPage:any = HomePage;
  loader: any;
  pages:any[]=[];

  constructor(platform: Platform, statusBar: StatusBar,
              splashScreen: SplashScreen,
              private app:App,
              private loadingCtrl:LoadingController,
              private storage:Storage,
              private config:ConfigService,
              private imgcacheService:ImgcacheService) {
    this.presentLoading();
    platform.ready().then(() => {
      // Okay, so the platform is ready and our plugins are available.
      // Here you can do any higher level native things you might need.
      statusBar.styleDefault();
      splashScreen.hide();

      this.setRoot();
    });

    this.pages =[
      { title: 'Home', component: TabsPage, index: 0, hide:false},
      /*{ title: 'Website', component: InstructorsPage, index: 3, hide:false},
      { title: 'Magazine', component: BlogPage, index: 1, hide:false},
      { title: 'Contact', component: ContactPage, index: 4, hide:false},*/
    ];
  }

  ngOnInit(){
    this.config.initialize();
  }

  setRoot() {
    this.storage.get('introShown').then((result) => {
      if(result){
        this.imgcacheService.initImgCache().then(() => {
          this.rootPage = TabsPage;
          this.loader.dismiss();
        });


      } else {
        this.rootPage = TutorialPage;

        let nav = this.app.getRootNav();
        this.imgcacheService.initImgCache().then(() => {
          nav.setRoot(this.rootPage);
          this.loader.dismiss();
        });

      }
    });
  }

  presentLoading() {
    this.loader = this.loadingCtrl.create({
      //content: "Loading..."
    });
    this.loader.present();
  }
}

