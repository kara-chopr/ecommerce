import { Component, OnInit, ViewChild, Output, EventEmitter } from '@angular/core';
import {
  NavController, NavParams, ModalController, LoadingController, AlertController, Platform, Slides,
  ToastController
} from 'ionic-angular';
import { DomSanitizer} from '@angular/platform-browser';

import { Audio } from '../../models/audio';
import { User } from '../../models/user';
import { AudioStatus } from '../../models/status';

import { AudioService } from '../../services/audio';
import { UserService } from '../../services/users';
import { AudioStatusService } from '../../services/status';
import { ConfigService } from '../../services/config';


import { Storage } from '@ionic/storage';
import { DocumentViewer, DocumentViewerOptions } from '@ionic-native/document-viewer';

import { VgAPI } from 'videogular2/core';


@Component({
  selector: 'page-audio-status',
  templateUrl: 'audio-status.html'
})
export class AudioStatusPage implements OnInit{

  isLoggedIn: boolean = true;
  audiostatus:AudioStatus;
  audio:any;
  user: any;

  api:VgAPI;

  @ViewChild('CourseStatusItems') courseStatusItems: Slides;


  constructor(public navCtrl: NavController,
              public navParams: NavParams,
              private modalCtrl: ModalController,
              private alert:AlertController,
              private userService:UserService,
              private document: DocumentViewer,
              private toastCtrl: ToastController,
              private config:ConfigService,
              private storage: Storage,
              private audioService:AudioService,
              private loadingCtrl:LoadingController,
              private sanitizer: DomSanitizer) {}

  ngOnInit(){
    let data:any;

    data  = this.navParams.data;

    if(data.hasOwnProperty('audio')){
      this.storage.set('lastaudio',data);
    }else{
      data = this.audioService.getLastAudio();
    }


    this.audio = data['audio'];
    this.user = data['user'];

    if(this.audio){
      if(!('name' in this.audio)){
        this.storage.get('audio'+this.user.id).then(res=>{
          if(res && Array.isArray(res)){
            for(let k=0;k<res.length;k++){
              if(this.audio.id == res[k].id){
                this.audio = res[k];
              }
            }
          }
        });
      }

      let progress:number = parseFloat(this.audio.user_progress);
      this.audiostatus = {
        'audio_id':this.audio.id,
        'user_id':this.user.id,
        'progress':Number(progress),
        'audio_file':this.audio.audio_download,
        'pdf_file':this.audio.pdf_download,
        'image': this.audio.featured_img,
        'description': this.audio.description,
        'wpm': this.audio.wpm,
        'word_count': this.audio.word_count,
        'language': this.audio.language,
        'magazine': this.audio.magazine,
        'courseitems':[],
        'status':this.audio.user_status,
      };


    }
  }

  ionViewDidLoad(){

    if(this.audio.id != this.audiostatus.audio_id){ // New course has been loaded
      console.log('New course to be loaded');
      let progress:number = parseFloat(this.audio.user_progress);
      this.audiostatus = {
        'audio_id':this.audio.id,
        'user_id':this.user.id,
        'progress':Number(progress),
        'audio_file':this.audio.audio_download,
        'pdf_file':this.audio.pdf_download,
        'image': this.audio.featured_img,
        'description': this.audio.description,
        'wpm': this.audio.wpm,
        'word_count': this.audio.word_count,
        'language': this.audio.language,
        'magazine': this.audio.magazine,
        'courseitems':[],
        'status':this.audio.user_status,
      };

      let loading = this.loadingCtrl.create({
        content: '<img src="assets/imgs/bubbles.svg">',
        duration: 15000,//this.config.get_translation('loadingresults'),
        spinner:'hide',
        showBackdrop:true,

      });

      console.log(this.audiostatus);

    }
  }

  onPlayerReady(api:VgAPI) {
    this.api = api;
    console.log('fired');
    this.api.getDefaultMedia().subscriptions.playing.subscribe(
      () => {
        console.log('playing');
      }
    )
    this.api.getDefaultMedia().subscriptions.ended.subscribe(
      () => {
        // Set the video to the beginning
        this.api.getDefaultMedia().currentTime = 0;
        this.finishAudio()
        console.log('audio ended', this.api.getDefaultMedia().currentTime);
      }
    );
  }

  showPdf() {
    if(this.audiostatus.progress = 100) {

      var data = { pdf : this.audiostatus.pdf_file };
      var modalPage = this.modalCtrl.create('ModalPage',data);
      modalPage.present();
      const options: DocumentViewerOptions = {
        title: 'My PDF'
      }
      this.document.viewDocument(this.audiostatus.pdf_file, 'application/pdf', options)
    } else {
      let toast = this.toastCtrl.create({
        message: 'Please complete course first',
        duration: 1000,
        position: 'bottom'
      });

      toast.present();
    }
  }

  finishAudio() {
    let loading = this.loadingCtrl.create({
      content: '<img src="assets/imgs/bubbles.svg">',
      duration: 15000,//this.config.get_translation('loadingresults'),
      spinner:'hide',
      showBackdrop:true,

    });
    loading.present();

    this.storage.get('audios_'+this.audiostatus.user_id).then(audios=>{
      console.log('Modifying saved coruses ');
      if(audios.length){
        for(let k=0;k<audios.length;k++){
          if(audios[k].id == this.audiostatus.audio_id){
            console.log('modify #2 '+audios[k].name);
            audios[k].user_progress = 100;
            audios[k].user_status = 4;
            //Update my courses
            this.storage.set('audios_'+this.audiostatus.user_id,audios);
          }
        }
      }

      loading.dismiss();
    });

  }

}
