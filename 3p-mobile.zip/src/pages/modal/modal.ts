import {Component, OnInit} from '@angular/core';
import { IonicPage, NavController, NavParams, ViewController } from 'ionic-angular';
import { DomSanitizer} from '@angular/platform-browser';

import { PdfViewerModule } from 'ng2-pdf-viewer';

/**
 * Generated class for the ModalPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-modal',
  templateUrl: 'modal.html',
})
export class ModalPage implements OnInit{
  pdfLink:any;

  constructor(public navCtrl: NavController, public navParams: NavParams,
              public viewCtrl : ViewController, private sanitizer: DomSanitizer) {

  }

  ngOnInit(){
    let data:any;

    data  = this.navParams.data.pdf;

    this.pdfLink = data;
    console.log(this.pdfLink);
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ModalPage');
    console.log(this.navParams.get('message'));
  }

  public closeModal(){
    this.viewCtrl.dismiss();
  }
}
